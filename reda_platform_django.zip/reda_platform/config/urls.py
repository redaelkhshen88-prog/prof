from django.contrib import admin
from django.urls import include, path
urlpatterns = [
    path("admin/", admin.site.urls),
    path("", include("courses.urls")),
    path("", include("accounts.urls")),
    path("billing/", include("billing.urls")),
]
